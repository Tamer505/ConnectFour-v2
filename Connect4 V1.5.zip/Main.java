public class Main{
    private int e;
    public static void main(String[] args){
        Board b = new Board();
        GameFrame g = new GameFrame();
        g.setBoard(b);
    }
}